
$('#cart').click(function(){
  $('#overlay').addClass('is-visible')
});
$('#close-me').click(function(){
  $('#overlay').removeClass('is-visible')
});
